// ─────────────────────────────────────────────
// 🚀 STATE TRACKING
// ─────────────────────────────────────────────
let lastScanResult = {
  scanned: false,
  profileName: "Waiting...",
  count: 0,
  mismatchFound: false,
  noElements: true
};

let savedProfileName = null;
chrome.storage.local.get(['savedProfileName'], (res) => {
  if (res.savedProfileName) savedProfileName = res.savedProfileName;
});

let scanTimeout = null;
let isScanning = false;

// ─────────────────────────────────────────────
// 🚀 AUTO START
// ─────────────────────────────────────────────
window.addEventListener("load", () => {
  setTimeout(initScanner, 1500);
});

function initScanner() {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "SCAN_NAMES") {
      runScan();
      sendResponse({ status: "scanned", result: lastScanResult });
    } else if (request.action === "GET_STATUS") {
      sendResponse({ status: "success", result: lastScanResult });
    }
  });
  observeChanges();
  runScan();
}

// ─────────────────────────────────────────────
// 🔁 Re-scan on React DOM changes (debounced)
// ─────────────────────────────────────────────
function observeChanges() {
  const observer = new MutationObserver(() => {
    if (isScanning) return;
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(() => { runScan(); }, 1000);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
}

// ─────────────────────────────────────────────
// 🗂️ TAB DETECTION
// Returns: "profile" | "empinfo" | "ocr" | "unknown"
// ─────────────────────────────────────────────
function getActiveTab() {
  // Method 1: Find active tab button by class/aria
  const tabCandidates = Array.from(document.querySelectorAll(
    'button, [role="tab"], .tab, [class*="tab"], nav a'
  ));

  for (const el of tabCandidates) {
    const text = el.innerText?.trim().toLowerCase();
    if (!text) continue;
    if (!["profile", "ocr", "emp info", "empinfo", "emp_info"].includes(text)) continue;

    const style = window.getComputedStyle(el);
    const isActive =
      el.classList.contains('active') ||
      el.classList.contains('selected') ||
      el.getAttribute('aria-selected') === 'true' ||
      el.getAttribute('data-active') === 'true' ||
      style.backgroundColor === 'rgb(59, 130, 246)' ||
      style.backgroundColor === 'rgb(37, 99, 235)' ||
      style.color === 'rgb(59, 130, 246)';

    if (isActive) {
      if (text.includes("profile")) return "profile";
      if (text.includes("ocr")) return "ocr";
      if (text.includes("emp")) return "empinfo";
    }
  }

  // Method 2: Unique content signals per tab
  const pageText = document.body.innerText || "";

  if (
    pageText.includes("NSDL Name") ||
    pageText.includes("NSDL PAN Display Name") ||
    pageText.includes("NSDL PAN - Aadhaar linked") ||
    pageText.includes("Govt ID No")
  ) {
    return "profile";
  }

  if (
    pageText.includes("Employment Details") &&
    pageText.includes("Employment Type") &&
    !pageText.includes("NSDL Name")
  ) {
    return "empinfo";
  }

  return "unknown";
}

// ─────────────────────────────────────────────
// 🎯 MAIN SCAN
// ─────────────────────────────────────────────
function runScan() {
  if (isScanning) return;
  isScanning = true;

  try {
    clearHighlights();
    removeUI(); // clear any stale toast immediately on every scan

    const activeTab = getActiveTab();
    let profileEl = null;
    let currentProfileName = null;

    // Only extract profile name when on Profile tab
    if (activeTab === "profile") {
      profileEl = findProfileNameInDOM();
      if (profileEl) {
        const extracted = (profileEl.tagName === 'INPUT' ? profileEl.value : profileEl.innerText)?.trim();
        // Trust the extraction if we found an element (bypasses strict isLikelyPersonName to avoid missing single-word names)
        if (extracted) {
          currentProfileName = extracted;
          savedProfileName = currentProfileName;
          chrome.storage.local.set({ savedProfileName: currentProfileName });
        }
      }
    }

    // On all other tabs, use saved name from Profile tab
    if (!currentProfileName) {
      currentProfileName = savedProfileName;
    }

    // Bank holder name — safe on all tabs, strictly label-anchored
    const bankEls = findBankAccountHolderNames();

    if (!currentProfileName || bankEls.length === 0) {
      lastScanResult = {
        scanned: false,
        profileName: currentProfileName || "Not found — visit Profile tab first",
        count: bankEls.length,
        mismatchFound: false,
        noElements: true
      };
      
      removeUI(); // always clear stale toast on early exit
      chrome.runtime.sendMessage({ action: "UPDATE_STATUS", result: lastScanResult }).catch(() => { });
      return;
    }

    let mismatchFound = false;

    bankEls.forEach(el => {
      const rawBankName = (el.tagName === 'INPUT' ? el.value : el.innerText)?.trim() || "";
      // ✅ Extract only the person's name — strip parentage, address, junk
      const bankName = extractPersonName(rawBankName);
      const result = compareNames(currentProfileName, bankName);

      if (result === "match") {
        highlight(el, "green");
      } else if (result === "partial") {
        highlight(el, "orange");
      } else {
        highlight(el, "red");
        mismatchFound = true;
      }
    });

    if (profileEl && activeTab === "profile") {
      highlight(profileEl, mismatchFound ? "red" : "green");
    }

    lastScanResult = {
      scanned: true,
      profileName: currentProfileName,
      count: bankEls.length,
      mismatchFound,
      noElements: false
    };

    showStatusUI(currentProfileName, bankEls.length, mismatchFound);
    chrome.runtime.sendMessage({ action: "UPDATE_STATUS", result: lastScanResult }).catch(() => { });

  } catch (err) {
    console.error("NameCheck Scan Error:", err);
  } finally {
    setTimeout(() => { isScanning = false; }, 300);
  }
}

// ─────────────────────────────────────────────
// ✂️ NAME EXTRACTION — strips parentage & junk
//
// Handles formats like:
//   "SACHIN S/O RAM JATAN"           → "SACHIN"
//   "PRIYA D/O MOHAN LAL"            → "PRIYA"
//   "RAMESH W/O SURESH KUMAR"        → "RAMESH"
//   "AMIT KUMAR S/O RAJESH"          → "AMIT KUMAR"
//   "RATHOD CHANDRASINH"             → "RATHOD CHANDRASINH" (unchanged)
//   "JOHN DOE, 12 MG ROAD, MUMBAI"   → "JOHN DOE" (strip address after comma)
//   "SUNDAR C/O KRISHNA NAGAR"       → "SUNDAR"
// ─────────────────────────────────────────────
function extractPersonName(raw) {
  let name = raw;

  // Step 1: Strip anything after a comma (address mixed in)
  name = name.split(",")[0].trim();

  // Step 2: Strip parentage patterns — S/O, D/O, W/O, C/O, F/O, H/O
  // Pattern: NAME <RELATION/O> REST  →  keep only NAME part before the marker
  // Also handles: S.O., D.O, W.O, SON OF, DAUGHTER OF, WIFE OF, CARE OF
  name = name
    .replace(/\b(s\/o|d\/o|w\/o|c\/o|f\/o|h\/o|s\.o\.|d\.o\.|w\.o\.|c\.o\.)\b.*/i, "")
    .replace(/\b(son of|daughter of|wife of|care of|husband of|father of)\b.*/i, "")
    .trim();

  // Step 3: Strip trailing punctuation/noise
  name = name.replace(/[,.\-:;]+$/, "").trim();

  // Step 4: If what remains looks like a person name, return it
  // Otherwise return the original raw (don't lose data)
  if (name.length >= 2 && /^[A-Za-z\s.\-]+$/.test(name)) {
    return name;
  }

  // Fallback: return raw stripped of only the punctuation
  return raw.split(",")[0].trim();
}

// ─────────────────────────────────────────────
// 🧠 DOM HELPERS
// ─────────────────────────────────────────────

function isTightest(el, text) {
  for (const child of el.children) {
    const ct = (child.tagName === 'INPUT' ? child.value : child.innerText)?.trim();
    if (ct && ct.toLowerCase() === text.toLowerCase()) return false;
  }
  return true;
}

/**
 * Find the profile name element — ONLY call on Profile tab.
 * Strict label-anchored. No open-ended UPPERCASE heuristic.
 */
function findProfileNameInDOM() {
  const allNodes = Array.from(document.querySelectorAll("*"));

  for (let i = 0; i < allNodes.length; i++) {
    const el = allNodes[i];
    const originalText = el.innerText?.trim() || "";
    const text = originalText.toLowerCase().replace(/[:\-]/g, "").replace(/\s+/g, " ");

    const isProfileLabel = 
      text === "nsdl name" || 
      text === "nsdl pan display name" || 
      text === "profile name" || 
      text === "applicant name" || 
      text === "customer name" ||
      text === "name";

    if (!isProfileLabel) continue;
    if (!isTightest(el, originalText)) continue;

    for (let j = i + 1; j < i + 25 && j < allNodes.length; j++) {
      const nextEl = allNodes[j];
      const nextText = (nextEl.tagName === 'INPUT' ? nextEl.value : nextEl.innerText)?.trim();
      if (!nextText || nextText.toLowerCase() === originalText.toLowerCase()) continue;
      if (!isTightest(nextEl, nextText)) continue;
      
      // Stop if we hit the next label (means value is empty)
      const lower = nextText.toLowerCase();
      if (lower === "gender" || lower === "dob" || lower.includes("pan ") || lower.includes("govt id") || lower.includes("mobile no")) {
         break;
      }
      
      return nextEl; // Trust this is the name
    }
  }

  // Fallback: prominent UPPERCASE heading near top of viewport, strictly validated
  for (const el of allNodes) {
    const text = (el.tagName === 'INPUT' ? el.value : el.innerText)?.trim();
    if (!text || !isTightest(el, text)) continue;
    const words = text.trim().split(/\s+/);
    if (words.length >= 2 && words.length <= 5 && text === text.toUpperCase()) {
      if (isLikelyPersonName(text)) {
        const rect = el.getBoundingClientRect();
        if (rect.top >= 0 && rect.top < 350) return el;
      }
    }
  }

  return null;
}

/**
 * Validates that a string looks like a human person name.
 * Rejects state names, company names, UI labels, numeric strings.
 */
function isLikelyPersonName(text) {
  if (!text || text.length < 3) return false;
  if (!/^[A-Za-z\s.\-]+$/.test(text)) return false;

  const words = text.trim().split(/\s+/);
  if (words.length < 2 || words.length > 6) return false;

  const REJECT = new Set([
    "ANDHRA", "PRADESH", "TELANGANA", "KARNATAKA", "KERALA", "TAMIL", "NADU",
    "MAHARASHTRA", "GUJARAT", "RAJASTHAN", "PUNJAB", "HARYANA", "BIHAR",
    "JHARKHAND", "ODISHA", "ASSAM", "BENGAL", "UTTARAKHAND", "HIMACHAL",
    "KASHMIR", "JAMMU", "GOA", "MANIPUR", "NAGALAND", "TRIPURA", "MEGHALAYA",
    "SIKKIM", "ARUNACHAL", "MIZORAM", "CHHATTISGARH", "UTTARPRADESH",
    "DELHI", "MUMBAI", "BANGALORE", "BENGALURU", "HYDERABAD", "CHENNAI",
    "KOLKATA", "PUNE", "AHMEDABAD", "SURAT", "JAIPUR", "LUCKNOW", "NAGPUR",
    "PVT", "LTD", "LIMITED", "PRIVATE", "COMPANY", "CORP", "INC", "LLC",
    "BANK", "FINANCE", "HOUSING", "CAPITAL", "SOLUTIONS", "SERVICES",
    "TECHNOLOGIES", "TECH", "SYSTEMS", "INDUSTRIES", "GROUP", "ENTERPRISES",
    "GOVT", "GOVERNMENT", "INDIA", "INDIAN", "ARMY", "NAVY", "AIRFORCE",
    "HINDUJA", "BAJAJ", "HDFC", "ICICI", "SBI", "AXIS", "KOTAK", "TATA",
    "BIRLA", "RELIANCE", "INFOSYS", "WIPRO", "HCL",
    "NSDL", "PAN", "DOB", "HOLD", "MANUAL", "CONFIRMED", "PROFILE", "OCR",
    "EMP", "INFO", "STATE", "CITY", "PINCODE", "ADDRESS", "MOBILE", "EMAIL",
    "SALARY", "VERSION", "POSITION", "SALARIED", "REMARKS", "UAN",
    "EMPLOYMENT", "DETAILS", "STATEMENT", "ACCOUNT", "HOLDER",
    "REUPLOAD", "RESET", "COMMENTS", "WHATSAPP", "HISTORY", "LIST",
  ]);

  for (const word of words) {
    if (REJECT.has(word.toUpperCase().replace(/\.$/, ""))) return false;
  }

  return true;
}

// ─────────────────────────────────────────────
// 🏦 BANK ACCOUNT HOLDER NAME FINDER
// Strictly label-anchored.
// ─────────────────────────────────────────────
function findBankAccountHolderNames() {
  const allNodes = Array.from(document.querySelectorAll("*"));
  const bankElements = [];

  const bankLabels = [
    "acc holder's name",
    "acc holder",
    "account holder name",
    "account holder's name",
    "account name",
    "beneficiary name"
  ];

  for (let i = 0; i < allNodes.length; i++) {
    const el = allNodes[i];
    const originalText = el.innerText?.trim() || "";
    const text = originalText.toLowerCase().replace(/[:\-]/g, "").replace(/\s+/g, " ");
    
    if (!text || !bankLabels.includes(text)) continue;
    if (!isTightest(el, originalText)) continue;

    for (let j = i + 1; j < i + 25 && j < allNodes.length; j++) {
      const nextEl = allNodes[j];
      const nextText = (nextEl.tagName === 'INPUT' ? nextEl.value : nextEl.innerText)?.trim();
      if (!nextText || nextText.toLowerCase() === originalText.toLowerCase()) continue;
      if (!isTightest(nextEl, nextText)) continue;

      // Stop if we hit the next label (value is empty)
      const lower = nextText.toLowerCase();
      if (lower === "mobile" || lower === "email" || lower === "pan" || lower.includes("account no") || lower.includes("ifsc")) {
         break;
      }

      // Run extractPersonName first, then validate the extracted part
      const extracted = extractPersonName(nextText);
      if (extracted && extracted.length >= 2) {
        bankElements.push(nextEl); // push the element, extraction happens at compare time
      }
      break;
    }
  }

  return [...new Set(bankElements)];
}

// ─────────────────────────────────────────────
// 🧠 ADVANCED NAME COMPARISON ENGINE
// ─────────────────────────────────────────────

function normalize(name) {
  return name
    .toLowerCase()
    // Strip parentage markers before normalizing
    .replace(/\b(s\/o|d\/o|w\/o|c\/o|f\/o|h\/o)\b.*/i, "")
    .replace(/\b(son of|daughter of|wife of|care of|husband of|father of)\b.*/i, "")
    // Strip titles
    .replace(/\b(mr|mrs|ms|dr|shri|smt|kumari|kum)\b\.?/g, "")
    // Strip non-alpha except spaces
    .replace(/[^a-z ]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenize(name) {
  return normalize(name).split(" ").filter(Boolean);
}

function significantTokens(tokens) {
  return tokens.filter(t => t.length > 1);
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) => [i]);
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

function fuzzyWordMatch(w1, w2) {
  if (w1 === w2) return true;
  if (!w1 || !w2) return false;

  // Initial match
  if (w1.length === 1 && w2.startsWith(w1)) return true;
  if (w2.length === 1 && w1.startsWith(w2)) return true;

  // Phonetic normalization for Indian names
  const ph = (w) => w
    .replace(/ee/g, "i")
    .replace(/aa/g, "a")
    .replace(/oo/g, "u")
    .replace(/ph/g, "f")
    .replace(/bh/g, "b")
    .replace(/dh/g, "d")
    .replace(/gh/g, "g")
    .replace(/kh/g, "k")
    .replace(/th/g, "t")
    .replace(/sh/g, "s")
    .replace(/nh/g, "n")
    .replace(/v/g, "w");

  if (ph(w1) === ph(w2)) return true;

  const minLen = Math.min(w1.length, w2.length);
  const maxEdits = minLen >= 8 ? 2 : minLen >= 5 ? 1 : 0;
  if (maxEdits > 0 && levenshtein(w1, w2) <= maxEdits) return true;

  return false;
}

/**
 * compareNames: "match" | "partial" | "mismatch"
 *
 * Handles:
 * - Parentage stripped:  "SACHIN S/O RAM JATAN" → compare only "SACHIN"
 * - Word-order swap:     RATHOD CHANDRASINH ↔ CHANDRASINH RATHOD
 * - Middle name absent:  CHANDRASINH RATHOD vs CHANDRASINH JITENDRASINH RATHOD
 * - Spelling variants:   RAGAVENDRAN vs RAGAVENDRA
 * - Initials:            R SIVAKUMAR vs RAGAVENDRAN SIVAKUMAR
 * - Concatenation:       HARIKRISHNAN vs HARI KRISHNAN
 * - Phonetic variants:   via levenshtein + phonetic normalization
 */
function compareNames(a, b) {
  // Pre-process: strip parentage from both sides before any comparison
  const cleanA = extractPersonName(a);
  const cleanB = extractPersonName(b);

  const n1 = normalize(cleanA);
  const n2 = normalize(cleanB);
  if (n1 === n2) return "match";

  const t1 = tokenize(cleanA);
  const t2 = tokenize(cleanB);

  if (t1.length === 0 || t2.length === 0) return "mismatch";

  // Sorted token match (any word order)
  if (t1.slice().sort().join(" ") === t2.slice().sort().join(" ")) return "match";

  // Concatenated form (spacing variants)
  if (t1.join("") === t2.join("")) return "match";

  const [shorter, longer] = t1.length <= t2.length ? [t1, t2] : [t2, t1];
  const sigS = significantTokens(shorter);
  const sigL = significantTokens(longer);

  // Subset: every sig token of shorter fuzzy-matches a token in longer
  // (handles middle name, word order)
  if (sigS.length > 0) {
    const used = new Set();
    let allFound = true;
    for (const sw of sigS) {
      let found = false;
      for (let i = 0; i < sigL.length; i++) {
        if (!used.has(i) && fuzzyWordMatch(sw, sigL[i])) {
          used.add(i); found = true; break;
        }
      }
      if (!found) { allFound = false; break; }
    }
    if (allFound) return "match";
  }

  // Initial variant matching
  const initVariant = (tokens) =>
    tokens.length > 1
      ? tokens.slice(0, -1).map(w => w[0]).join("") + " " + tokens[tokens.length - 1]
      : tokens[0] || "";

  const mkVariants = (tokens) => [
    tokens.join(""),
    initVariant(tokens),
    initVariant([...tokens].reverse()),
  ].filter(Boolean);

  for (const va of mkVariants(t1)) {
    for (const vb of mkVariants(t2)) {
      if (va === vb) return "match";
    }
  }

  // Fuzzy overlap scoring
  const overlapScore = (arr1, arr2) => {
    const used = new Set();
    let score = 0;
    for (const w of arr1) {
      if (w.length <= 1) continue;
      for (let i = 0; i < arr2.length; i++) {
        if (!used.has(i) && fuzzyWordMatch(w, arr2[i])) {
          used.add(i); score++; break;
        }
      }
    }
    return score;
  };

  const s1 = overlapScore(sigS, sigL);
  const s2 = overlapScore(sigL, sigS);

  if (s1 >= sigS.length && sigS.length > 0) return "match";
  if (s2 >= sigL.length && sigL.length > 0) return "match";

  const total = sigS.length + sigL.length;
  if (total > 0 && (s1 + s2) / total >= 0.5) return "partial";

  // Last name fuzzy match
  const last1 = t1[t1.length - 1], last2 = t2[t2.length - 1];
  if (last1 && last2 && last1.length > 2 && fuzzyWordMatch(last1, last2)) return "partial";

  // First name fuzzy match
  const f1 = t1[0], f2 = t2[0];
  if (f1 && f2 && f1.length > 2 && fuzzyWordMatch(f1, f2)) return "partial";

  return "mismatch";
}

// ─────────────────────────────────────────────
// 🎨 HIGHLIGHT
// ─────────────────────────────────────────────
function highlight(el, type) {
  const colors = { green: "#16a34a", orange: "#f59e0b", red: "#dc2626" };
  if (!el.classList.contains('namecheck-highlighted')) {
    el.dataset.originalOutline = el.style.outline || "";
    el.dataset.originalBoxShadow = el.style.boxShadow || "";
    el.dataset.originalBorderRadius = el.style.borderRadius || "";
  }
  el.style.outline = `3px solid ${colors[type]}`;
  el.style.borderRadius = "6px";
  el.style.boxShadow = `0 0 12px ${colors[type]}aa`;
  el.classList.add('namecheck-highlighted');
}

function clearHighlights() {
  document.querySelectorAll(".namecheck-highlighted").forEach(el => {
    el.style.outline = el.dataset.originalOutline || "";
    el.style.boxShadow = el.dataset.originalBoxShadow || "";
    el.style.borderRadius = el.dataset.originalBorderRadius || "";
    el.classList.remove('namecheck-highlighted');
  });
}

// ─────────────────────────────────────────────
// 📊 FLOATING STATUS UI
// Auto-dismisses after 3s. Always removed at scan
// start so it never gets stuck on screen.
// ─────────────────────────────────────────────
let uiDismissTimer = null;

function showStatusUI(label, count, mismatch) {
  removeUI();

  const box = document.createElement("div");
  box.id = "name-check-ui";
  box.innerText = mismatch
    ? `❌ Mismatch Found\nChecked: ${count}`
    : `✅ All Match\nChecked: ${count}`;

  Object.assign(box.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    background: "#111",
    color: "white",
    padding: "10px 14px",
    borderRadius: "8px",
    fontSize: "12px",
    zIndex: 999999,
    boxShadow: "0 0 10px rgba(0,0,0,0.5)",
    pointerEvents: "none",
    transition: "opacity 0.4s ease",
    opacity: "1"
  });

  document.body.appendChild(box); s

  // Auto-dismiss after 3 seconds with fade
  clearTimeout(uiDismissTimer);
  uiDismissTimer = setTimeout(() => {
    box.style.opacity = "0";
    setTimeout(() => removeUI(), 420);
  }, 3000);
}

function removeUI() {
  clearTimeout(uiDismissTimer);
  const existing = document.querySelector("#name-check-ui");
  if (existing) existing.remove();
}