document.addEventListener("DOMContentLoaded", async () => {
  const scanBtn = document.getElementById("scanBtn");
  const monitoringStatus = document.getElementById("monitoring-status");
  const statusText = document.getElementById("status-text");
  const valProfile = document.getElementById("val-profile");
  const valCount = document.getElementById("val-count");
  const resultBox = document.getElementById("result-box");
  const resultIcon = document.getElementById("result-icon");
  const resultText = document.getElementById("result-text");
  const contentContainer = document.getElementById("content-container");

  // Get active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || tab.url.startsWith("chrome://") || tab.url.startsWith("edge://")) {
    setDisconnectedState();
    return;
  }

  // Initial connection and data fetch
  connectToContentScript();

  // Listen for real-time updates
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "UPDATE_STATUS" && request.result) {
      updateUI(request.result);
    }
  });

  // Handle manual scan button click
  scanBtn.addEventListener("click", () => {
    scanBtn.disabled = true;
    scanBtn.innerHTML = '<div class="loading-spinner"></div> Scanning...';
    
    chrome.tabs.sendMessage(tab.id, { action: "SCAN_NAMES" }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setDisconnectedState();
      } else if (response.result) {
        updateUI(response.result);
      }
      
      setTimeout(() => {
        scanBtn.disabled = false;
        scanBtn.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"></path>
            <path d="M21 3v5h-5"></path>
          </svg>
          Force Scan
        `;
      }, 500);
    });
  });

  function connectToContentScript() {
    chrome.tabs.sendMessage(tab.id, { action: "GET_STATUS" }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setDisconnectedState();
      } else {
        setConnectedState();
        if (response.result) {
          updateUI(response.result);
        }
      }
    });
  }

  function setConnectedState() {
    monitoringStatus.className = "status-badge";
    statusText.innerText = "Monitoring";
    contentContainer.classList.add("visible");
  }

  function setDisconnectedState() {
    monitoringStatus.className = "status-badge waiting";
    statusText.innerText = "Inactive";
    contentContainer.classList.add("visible");
    scanBtn.disabled = true;
    
    valProfile.innerText = "N/A";
    valCount.innerText = "0";
    resultIcon.innerText = "⚠️";
    resultText.innerText = "Cannot scan this page";
    resultText.className = "result-text none";
  }

  function updateUI(data) {
    if (!data.scanned) return;

    valProfile.innerText = data.profileName || "Not found";
    valProfile.title = data.profileName || "Not found";
    valCount.innerText = data.count || "0";

    if (data.noElements) {
      resultIcon.innerText = "🔍";
      resultText.innerText = "No data found";
      resultText.className = "result-text none";
      resultBox.style.borderColor = "var(--border)";
      resultBox.style.background = "rgba(255, 255, 255, 0.03)";
    } else if (data.mismatchFound) {
      resultIcon.innerText = "❌";
      resultText.innerText = "Mismatch Detected";
      resultText.className = "result-text mismatch";
      resultBox.style.borderColor = "rgba(239, 68, 68, 0.3)";
      resultBox.style.background = "rgba(239, 68, 68, 0.05)";
    } else {
      resultIcon.innerText = "✅";
      resultText.innerText = "All Names Match";
      resultText.className = "result-text match";
      resultBox.style.borderColor = "rgba(16, 185, 129, 0.3)";
      resultBox.style.background = "rgba(16, 185, 129, 0.05)";
    }
  }
});